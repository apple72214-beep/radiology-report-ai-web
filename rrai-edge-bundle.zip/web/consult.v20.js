/* Teleradiology consultation packages — offline-first, fail-closed.
   schema rrai-consult/1 (referral) and rrai-consult-reply/1 (read-back).
   Integrity: SHA-256 over canonical payload; validator rejects any mismatch. */

const SCHEMA = "rrai-consult/1";
const SCHEMA_REPLY = "rrai-consult-reply/1";

/* Pure-JS SHA-256 fallback: crypto.subtle is blocked on non-secure
   contexts (plain http:// LAN servers — the Docker edge deployment). */
export function sha256FallbackHex(bytes) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  let H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const l = bytes.length;
  const pad = new Uint8Array((((l + 8) >> 6) + 1) << 6);
  pad.set(bytes);
  pad[l] = 0x80;
  const dv = new DataView(pad.buffer);
  dv.setUint32(pad.length - 8, Math.floor(l / 536870912));
  dv.setUint32(pad.length - 4, (l * 8) >>> 0);
  const w = new Uint32Array(64);
  const rotr = (x, n) => ((x >>> n) | (x << (32 - n))) >>> 0;
  for (let off = 0; off < pad.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = dv.getUint32(off + i * 4);
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i-15],7) ^ rotr(w[i-15],18) ^ (w[i-15] >>> 3);
      const s1 = rotr(w[i-2],17) ^ rotr(w[i-2],19) ^ (w[i-2] >>> 10);
      w[i] = (w[i-16] + s0 + w[i-7] + s1) >>> 0;
    }
    let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
      const ch = (e & f) ^ ((~e >>> 0) & g);
      const t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
      const S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H = [(H[0]+a)>>>0,(H[1]+b)>>>0,(H[2]+c)>>>0,(H[3]+d)>>>0,(H[4]+e)>>>0,(H[5]+f)>>>0,(H[6]+g)>>>0,(H[7]+h)>>>0];
  }
  return H.map((x) => x.toString(16).padStart(8, "0")).join("");
}

async function sha256(obj) {
  const bytes = new TextEncoder().encode(JSON.stringify(obj));
  if (globalThis.crypto && globalThis.crypto.subtle) {
    try {
      const buf = await globalThis.crypto.subtle.digest("SHA-256", bytes);
      return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch (e) { /* fall through to JS */ }
  }
  return sha256FallbackHex(bytes);
}

export async function buildPackage(input) {
  const payload = {
    schema: input.reply ? SCHEMA_REPLY : SCHEMA,
    createdAt: new Date().toISOString(),
    actor: input.actor || "unknown",
    note: input.note || "",
    study: input.study
      ? {
          uid: input.study.uid,
          patient: input.study.patient,
          modality: input.study.modality,
          description: input.study.description || "",
          bodyPart: input.study.bodyPart || "",
          frames: (input.study.frames || []).map((f) => ({ w: f.w, h: f.h })),
        }
      : null,
    triage: input.triage || null,
    reportText: input.reportText || "",
    measurePts: input.measurePts || [],
    snapshotPng: input.snapshotPng || "",
    refHash: input.refHash || "",
    refUid: input.refUid || "",
  };
  const hash = await sha256(payload);
  return { schema: payload.schema, hash, payload };
}

export async function validatePackage(pkg) {
  const errors = [];
  if (!pkg || typeof pkg !== "object") return { ok: false, errors: ["الحزمة ليست كائنًا صالحًا"] };
  if (pkg.schema !== SCHEMA && pkg.schema !== SCHEMA_REPLY) errors.push("مخطط غير معروف: " + pkg.schema);
  if (!pkg.payload) errors.push("لا حمولة داخل الحزمة");
  if (!pkg.hash) errors.push("لا بصمة SHA-256");
  let hashOk = false;
  if (pkg.payload && pkg.hash) {
    const h = await sha256(pkg.payload);
    hashOk = h === pkg.hash;
    if (!hashOk) errors.push("البصمة لا تطابق المحتوى — عبث محتمل");
  }
  if (pkg.schema === SCHEMA_REPLY && !pkg.payload?.refHash) errors.push("رد بلا مرجعية");
  return { ok: errors.length === 0, errors, hashOk, isReply: pkg.schema === SCHEMA_REPLY };
}

export function downloadJson(obj, filename) {
  const blob = new Blob([JSON.stringify(obj)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
}
